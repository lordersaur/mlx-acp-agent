use anyhow::{Context, Result};
use reqwest::Client;
use serde::{Deserialize, Serialize};
use serde_json::{Map, Value};

use crate::config::AppConfig;

// ---------------------------------------------------------------------------
// Wire-format message types
// ---------------------------------------------------------------------------

/// A single message in a chat completion request or response.
/// Mirrors the OpenAI chat message schema.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct ChatMessage {
    pub role: String,
    /// `None` for assistant messages that only contain tool calls.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub content: Option<String>,
    /// Present on assistant messages that contain tool calls.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub tool_calls: Option<Vec<ChatToolCall>>,
    /// Present on `tool` role messages to correlate with the assistant call.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub tool_call_id: Option<String>,
}

impl ChatMessage {
    pub fn user(content: impl Into<String>) -> Self {
        Self {
            role: "user".into(),
            content: Some(content.into()),
            tool_calls: None,
            tool_call_id: None,
        }
    }

    pub fn system(content: impl Into<String>) -> Self {
        Self {
            role: "system".into(),
            content: Some(content.into()),
            tool_calls: None,
            tool_call_id: None,
        }
    }

    pub fn assistant(content: impl Into<String>) -> Self {
        Self {
            role: "assistant".into(),
            content: Some(content.into()),
            tool_calls: None,
            tool_call_id: None,
        }
    }

    pub fn assistant_with_tool_calls(tool_calls: Vec<ChatToolCall>) -> Self {
        Self {
            role: "assistant".into(),
            content: None,
            tool_calls: Some(tool_calls),
            tool_call_id: None,
        }
    }

    pub fn tool_result(tool_call_id: impl Into<String>, content: impl Into<String>) -> Self {
        Self {
            role: "tool".into(),
            content: Some(content.into()),
            tool_calls: None,
            tool_call_id: Some(tool_call_id.into()),
        }
    }
}

/// A tool call emitted by the assistant.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct ChatToolCall {
    pub id: String,
    #[serde(rename = "type")]
    pub kind: String,
    pub function: ChatToolCallFunction,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct ChatToolCallFunction {
    pub name: String,
    /// Arguments encoded as a JSON string (OpenAI wire format).
    pub arguments: String,
}

// ---------------------------------------------------------------------------
// Structured result returned from the model
// ---------------------------------------------------------------------------

/// Parsed result from a single completion call.
#[derive(Debug, Clone)]
pub struct CompletionResult {
    /// The assistant's text response when no tool calls were emitted.
    pub content: Option<String>,
    /// Structured tool calls when the model chose to call tools.
    pub tool_calls: Vec<ApiToolCall>,
}

/// A single structured tool call ready for execution.
#[derive(Debug, Clone)]
pub struct ApiToolCall {
    /// Identifier used to correlate the result back to this call.
    pub id: String,
    pub name: String,
    pub arguments: Map<String, Value>,
}

impl ApiToolCall {
    fn from_chat(c: &ChatToolCall) -> Option<Self> {
        let arguments: Value = serde_json::from_str(&c.function.arguments).ok()?;
        let arguments = match arguments {
            Value::Object(map) => map,
            _ => Map::new(),
        };
        Some(Self {
            id: c.id.clone(),
            name: c.function.name.clone(),
            arguments,
        })
    }
}

// ---------------------------------------------------------------------------
// Client
// ---------------------------------------------------------------------------

#[derive(Debug, Clone)]
pub struct MlxClient {
    client: Client,
    endpoint: String,
    model: String,
}

impl MlxClient {
    pub fn from_config(config: &AppConfig) -> Result<Self> {
        let client = Client::builder()
            .use_rustls_tls()
            .timeout(std::time::Duration::from_secs(120))
            .build()
            .context("failed to build reqwest client")?;

        Ok(Self {
            client,
            endpoint: config.mlx_url.clone(),
            model: config.mlx_model.clone(),
        })
    }

    pub async fn complete_raw(
        &self,
        messages: &[ChatMessage],
        tools: &[Value],
        max_tokens: u32,
        temperature: f32,
    ) -> Result<CompletionResult> {
        let tools_field = if tools.is_empty() {
            None
        } else {
            Some(tools.to_vec())
        };

        let payload = CompletionRequest {
            model: self.model.clone(),
            stream: false,
            messages: messages.to_vec(),
            max_tokens,
            temperature,
            tools: tools_field,
        };

        let response = self
            .client
            .post(&self.endpoint)
            .json(&payload)
            .send()
            .await
            .with_context(|| format!("failed to call MLX endpoint {}", self.endpoint))?
            .error_for_status()
            .with_context(|| format!("MLX endpoint returned error for {}", self.endpoint))?;

        let body: CompletionResponse = response
            .json()
            .await
            .context("failed to decode MLX response JSON")?;

        let choice = body
            .choices
            .into_iter()
            .next()
            .context("MLX response had no choices")?;

        let msg = choice.message;

        // Prefer structured tool_calls if present.
        if let Some(chat_calls) = msg.tool_calls {
            let api_calls = chat_calls
                .iter()
                .filter_map(ApiToolCall::from_chat)
                .collect();
            let text = normalize_content(msg.content).trim().to_owned();
            return Ok(CompletionResult {
                content: if text.is_empty() { None } else { Some(text) },
                tool_calls: api_calls,
            });
        }

        let text = normalize_content(msg.content).trim().to_owned();
        Ok(CompletionResult {
            content: if text.is_empty() { None } else { Some(text) },
            tool_calls: Vec::new(),
        })
    }
}

// ---------------------------------------------------------------------------
// Request / response serde types
// ---------------------------------------------------------------------------

#[derive(Debug, Serialize)]
struct CompletionRequest {
    model: String,
    stream: bool,
    messages: Vec<ChatMessage>,
    max_tokens: u32,
    temperature: f32,
    #[serde(skip_serializing_if = "Option::is_none")]
    tools: Option<Vec<Value>>,
}

#[derive(Debug, Deserialize)]
struct CompletionResponse {
    choices: Vec<Choice>,
}

#[derive(Debug, Deserialize)]
struct Choice {
    message: ChoiceMessage,
}

#[derive(Debug, Deserialize)]
struct ChoiceMessage {
    content: Option<Value>,
    #[serde(default)]
    tool_calls: Option<Vec<ChatToolCall>>,
}

fn normalize_content(content: Option<Value>) -> String {
    match content {
        None => String::new(),
        Some(Value::Null) => String::new(),
        Some(Value::String(text)) => text,
        Some(Value::Array(items)) => items
            .into_iter()
            .map(|item| match item {
                Value::Object(map) => map
                    .get("text")
                    .map(value_to_string)
                    .unwrap_or_else(|| Value::Object(map).to_string()),
                other => value_to_string(&other),
            })
            .collect::<Vec<_>>()
            .join("\n"),
        Some(other) => value_to_string(&other),
    }
}

fn value_to_string(value: &Value) -> String {
    match value {
        Value::Null => String::new(),
        Value::String(text) => text.clone(),
        Value::Bool(b) => b.to_string(),
        Value::Number(n) => n.to_string(),
        Value::Array(_) | Value::Object(_) => value.to_string(),
    }
}
