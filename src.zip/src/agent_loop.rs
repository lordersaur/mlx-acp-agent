use anyhow::Result;
use async_trait::async_trait;
use futures::future::join_all;
use serde_json::{Map, Value};

use crate::mlx_client::{
    ApiToolCall, ChatMessage, ChatToolCall, ChatToolCallFunction, CompletionResult, MlxClient,
};
use crate::model_parser::extract_thought_blocks;

pub const SYSTEM_PROMPT: &str = "\
You are a coding agent running inside the user's editor.

You have tools. You MUST use them for all file and workspace operations.

Rules:
- ALWAYS use tools to inspect before answering. Never guess about files, git state, or repo structure.
- Call tools directly. Do not substitute plans or descriptions for needed tool calls.
- For non-trivial or multi-step tasks, briefly explain what you are checking before your first tool call.
- Keep that reasoning concise: one or two short sentences, not a long essay.
- For trivial one-step tasks, skip the reasoning and just call the tool.
- You may call multiple tools in one response when they are independent.
- Prefer search_code_tool to locate the relevant files or symbols before reading large files.
- Before answering an abstract repo question, first identify the object type being asked about: HTTP routes/endpoints, RPC/protocol methods, tools/capabilities, config options, tests, commands, files, or schemas.
- Then inspect only the code that defines that object type. Do not substitute one object type for another.
- If the requested object type is absent, say so explicitly and name the closest related structure you found.
- For abstract repo questions, interpret the concept semantically before searching. Map terms like tools, routes, handlers, entrypoints, config, schema, tests, migrations, models, env vars, and jobs to the code structures that likely implement them.
- Do not start with a literal phrase search for an abstract concept unless the user explicitly asked for that exact phrase. Search for symbols, registry code, schema builders, dispatch code, filenames, or commands that represent the concept.
- If a literal search is weak, ambiguous, or returns no useful matches, pivot immediately to a structure-based search or a precise command. Do not conclude the concept is absent just because the phrase was absent.
- For tool definitions, inspect the full tool registry or schema builder and verify the complete set with a precise count. Do not infer the total from a partial file read or a truncated snippet.
- For routes, endpoints, or methods, inspect the actual registration or dispatch code and distinguish HTTP routes, RPC methods, CLI commands, and tool names. Do not assume \"routes\" means tools.
- If the repo is a protocol server rather than an HTTP app, say so explicitly and report the RPC/ACP methods or dispatch entries. Do not relabel tools as routes.
- For counting, totals, \"how many\", or \"which file has the most\" questions, prefer a precise run_command_tool command or exact file reads over broad search summaries.
- For Rust test counts, count actual test functions such as `#[test]` and `#[tokio::test]`. Do not count `#[cfg(test)]`, comments, plan files, or build artifacts as tests.
- For Rust repo-wide test counts, prefer a direct command such as `rg -n '#\\[test\\]|#\\[tokio::test\\]' src`.
- When the user asks what exists in the repo, prefer listing or reading the defining code over searching for a natural-language description of it.
- If the answer depends on a complete inventory, verify it with a command or a full registry/listing rather than stopping after the first relevant file.
- Before making a new tool call, review the evidence already gathered in this conversation and prefer reusing it over re-reading or relisting the same paths.
- Keep a short internal summary of: files/directories already inspected, key facts learned from them, and the remaining unanswered question.
- Do not reread the same file or relist the same directory unless you need different evidence than you already have.
- If one authoritative file, registry, or dispatch table answers the question, stop exploring and answer.
- Treat tool output as ground truth. Do not contradict a tool result, and do not answer \"no matches\" or \"no tests\" if a tool returned matches.
- Do not repeat the same search_code_tool query after it already returned usable results. Either answer from that evidence or switch to a more precise tool.
- Once you have enough evidence to answer accurately, stop calling tools and answer.
- If you already stated a conclusion in your reasoning (e.g. \"all tests passed\"), write that as your answer immediately. Do not make additional tool calls to reformat or \"provide a summary\" of information you already have.
- After editing files, validate with tests or builds when appropriate.
- Report results factually. Say what you found, what you changed, what passed/failed.
- If you can't do something, say so. Don't fake it.";

// ---------------------------------------------------------------------------
// Public types
// ---------------------------------------------------------------------------

/// A message from external callers (acp.rs history turns, system context).
/// Roles: "system", "user", "assistant".
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ConversationMessage {
    pub role: String,
    pub content: String,
    pub name: Option<String>,
}

impl ConversationMessage {
    pub fn new(role: impl Into<String>, content: impl Into<String>) -> Self {
        Self {
            role: role.into(),
            content: content.into(),
            name: None,
        }
    }
}

/// A single completed tool invocation — recorded in session history.
#[derive(Debug, Clone, PartialEq)]
pub struct ToolExecution {
    /// The `tool_call_id` from the model's tool call (used to correlate messages).
    pub id: String,
    pub name: String,
    pub arguments: Map<String, Value>,
    pub result: String,
    pub error: bool,
}

#[derive(Debug, Clone, PartialEq)]
pub struct LoopResult {
    pub answer: String,
    pub tool_results: Vec<ToolExecution>,
    pub iterations: usize,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct AgentLoopOptions {
    pub max_iterations: usize,
    pub max_tokens: u32,
    pub temperature: f32,
}

impl Default for AgentLoopOptions {
    fn default() -> Self {
        Self {
            max_iterations: 15,
            max_tokens: 1500,
            temperature: 0.0,
        }
    }
}

// ---------------------------------------------------------------------------
// Traits
// ---------------------------------------------------------------------------

#[async_trait]
pub trait ModelClient: Send + Sync {
    async fn complete(
        &self,
        messages: &[ChatMessage],
        tools: &[Value],
        max_tokens: u32,
        temperature: f32,
    ) -> Result<CompletionResult>;
}

#[async_trait]
impl ModelClient for MlxClient {
    async fn complete(
        &self,
        messages: &[ChatMessage],
        tools: &[Value],
        max_tokens: u32,
        temperature: f32,
    ) -> Result<CompletionResult> {
        self.complete_raw(messages, tools, max_tokens, temperature)
            .await
    }
}

#[async_trait]
pub trait ToolExecutor: Send + Sync {
    fn tool_names(&self) -> Vec<String>;

    async fn invoke(&self, name: &str, arguments: Map<String, Value>) -> Result<String>;

    fn has_tool(&self, name: &str) -> bool {
        self.tool_names().iter().any(|tool| tool == name)
    }
}

#[async_trait]
pub trait ThoughtHandler: Send {
    async fn on_thought(&mut self, thought: &str);
}

// ---------------------------------------------------------------------------
// Agent loop
// ---------------------------------------------------------------------------

pub async fn run_agent_loop(
    model: &dyn ModelClient,
    messages: &[ConversationMessage],
    tools: &dyn ToolExecutor,
    tool_schemas: &[Value],
    mut on_thought: Option<&mut dyn ThoughtHandler>,
    options: AgentLoopOptions,
) -> Result<LoopResult> {
    let mut all_tool_results: Vec<ToolExecution> = Vec::new();

    // Build the initial conversation as proper ChatMessages.
    let mut conversation: Vec<ChatMessage> = Vec::new();

    for msg in messages {
        match msg.role.as_str() {
            "system" => conversation.push(ChatMessage::system(&msg.content)),
            "assistant" => conversation.push(ChatMessage::assistant(&msg.content)),
            _ => conversation.push(ChatMessage::user(&msg.content)),
        }
    }

    debug_assert!(conversation.iter().skip(1).all(|m| m.role != "system"));

    for iteration in 0..options.max_iterations {
        let result = model
            .complete(
                &conversation,
                tool_schemas,
                options.max_tokens,
                options.temperature,
            )
            .await?;

        // Strip thought tokens from text content and surface them to the caller.
        let (thoughts, clean_text) = match result.content.as_deref() {
            Some(text) => {
                let (t, c) = extract_thought_blocks(text);
                (t, Some(c))
            }
            None => (Vec::new(), None),
        };

        if let Some(handler) = on_thought.as_deref_mut() {
            for thought in &thoughts {
                handler.on_thought(thought).await;
            }
        }

        let has_meaningful_text = clean_text
            .as_deref()
            .map(|t| !t.trim().is_empty())
            .unwrap_or(false);

        if has_meaningful_text && !result.tool_calls.is_empty() && !all_tool_results.is_empty() {
            return Ok(LoopResult {
                answer: clean_text.unwrap(),
                tool_results: all_tool_results,
                iterations: iteration + 1,
            });
        }
        if result.tool_calls.is_empty() {
            let answer = clean_text
                .filter(|t| !t.trim().is_empty())
                .unwrap_or_else(|| "No response.".to_owned());
            return Ok(LoopResult {
                answer,
                tool_results: all_tool_results,
                iterations: iteration + 1,
            });
        }

        // Surface any pre-tool reasoning text as a thought.
        if let Some(handler) = on_thought.as_deref_mut() {
            if let Some(ref text) = clean_text {
                if !text.trim().is_empty() {
                    handler.on_thought(text).await;
                }
            }
        }

        // Push assistant message with structured tool_calls.
        let chat_tool_calls: Vec<ChatToolCall> = result
            .tool_calls
            .iter()
            .map(|tc| ChatToolCall {
                id: tc.id.clone(),
                kind: "function".to_owned(),
                function: ChatToolCallFunction {
                    name: tc.name.clone(),
                    arguments: serde_json::to_string(&tc.arguments)
                        .unwrap_or_else(|_| "{}".to_owned()),
                },
            })
            .collect();
        conversation.push(ChatMessage::assistant_with_tool_calls(chat_tool_calls));

        // Execute tools (parallel when multiple).
        let executions = execute_tools(&result.tool_calls, tools).await;
        all_tool_results.extend(executions.iter().cloned());

        // Push tool result messages with matching tool_call_id.
        for exec in &executions {
            let content = if exec.error {
                format!("Error: {}", exec.result)
            } else {
                exec.result.clone()
            };
            conversation.push(ChatMessage::tool_result(&exec.id, content));
        }
    }

    Ok(LoopResult {
        answer: "Reached maximum iterations.".to_owned(),
        tool_results: all_tool_results,
        iterations: options.max_iterations,
    })
}

// ---------------------------------------------------------------------------
// Tool execution helpers
// ---------------------------------------------------------------------------

async fn execute_tools(tool_calls: &[ApiToolCall], tools: &dyn ToolExecutor) -> Vec<ToolExecution> {
    if tool_calls.len() == 1 {
        return vec![execute_one(&tool_calls[0], tools).await];
    }

    join_all(tool_calls.iter().map(|tc| execute_one(tc, tools))).await
}

async fn execute_one(tool_call: &ApiToolCall, tools: &dyn ToolExecutor) -> ToolExecution {
    if !tools.has_tool(&tool_call.name) {
        return ToolExecution {
            id: tool_call.id.clone(),
            name: tool_call.name.clone(),
            arguments: tool_call.arguments.clone(),
            result: format!(
                "Unknown tool: {}. Available: {}",
                tool_call.name,
                tools.tool_names().join(", ")
            ),
            error: true,
        };
    }

    match tools
        .invoke(&tool_call.name, tool_call.arguments.clone())
        .await
    {
        Ok(result) => ToolExecution {
            id: tool_call.id.clone(),
            name: tool_call.name.clone(),
            arguments: tool_call.arguments.clone(),
            result,
            error: false,
        },
        Err(error) => ToolExecution {
            id: tool_call.id.clone(),
            name: tool_call.name.clone(),
            arguments: tool_call.arguments.clone(),
            result: error.to_string(),
            error: true,
        },
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use std::collections::{HashMap, VecDeque};
    use std::sync::{Arc, Mutex};

    use anyhow::anyhow;
    use serde_json::json;
    use tokio::sync::Mutex as AsyncMutex;

    use super::*;
    use crate::mlx_client::{ApiToolCall, ChatMessage, CompletionResult};

    // ------------------------------------------------------------------
    // Mock model
    // ------------------------------------------------------------------

    struct MockModel {
        responses: AsyncMutex<VecDeque<CompletionResult>>,
        requests: Arc<AsyncMutex<Vec<Vec<ChatMessage>>>>,
    }

    impl MockModel {
        fn new(responses: Vec<CompletionResult>) -> Self {
            Self {
                responses: AsyncMutex::new(responses.into_iter().collect()),
                requests: Arc::new(AsyncMutex::new(Vec::new())),
            }
        }
    }

    #[async_trait]
    impl ModelClient for MockModel {
        async fn complete(
            &self,
            messages: &[ChatMessage],
            _tools: &[Value],
            _max_tokens: u32,
            _temperature: f32,
        ) -> Result<CompletionResult> {
            self.requests.lock().await.push(messages.to_vec());
            self.responses
                .lock()
                .await
                .pop_front()
                .ok_or_else(|| anyhow!("no mock responses left"))
        }
    }

    // ------------------------------------------------------------------
    // Mock tools
    // ------------------------------------------------------------------

    struct MockTools {
        names: Vec<String>,
        outputs: HashMap<String, Result<String>>,
        calls: Arc<Mutex<Vec<(String, Map<String, Value>)>>>,
    }

    impl MockTools {
        fn with_outputs(outputs: HashMap<String, Result<String>>) -> Self {
            let names = outputs.keys().cloned().collect();
            Self {
                names,
                outputs,
                calls: Arc::new(Mutex::new(Vec::new())),
            }
        }
    }

    #[async_trait]
    impl ToolExecutor for MockTools {
        fn tool_names(&self) -> Vec<String> {
            self.names.clone()
        }

        async fn invoke(&self, name: &str, arguments: Map<String, Value>) -> Result<String> {
            self.calls
                .lock()
                .expect("mock tool calls lock poisoned")
                .push((name.to_owned(), arguments));

            match self.outputs.get(name) {
                Some(Ok(result)) => Ok(result.clone()),
                Some(Err(error)) => Err(anyhow!(error.to_string())),
                None => Err(anyhow!("missing mock tool output")),
            }
        }
    }

    // ------------------------------------------------------------------
    // Thought recorder
    // ------------------------------------------------------------------

    #[derive(Default)]
    struct RecordingThoughts {
        thoughts: Vec<String>,
    }

    #[async_trait]
    impl ThoughtHandler for RecordingThoughts {
        async fn on_thought(&mut self, thought: &str) {
            self.thoughts.push(thought.to_owned());
        }
    }

    // ------------------------------------------------------------------
    // Tests
    // ------------------------------------------------------------------

    fn text_response(content: &str) -> CompletionResult {
        CompletionResult {
            content: Some(content.to_owned()),
            tool_calls: Vec::new(),
        }
    }

    fn tool_call_response(id: &str, name: &str, args: Value) -> CompletionResult {
        CompletionResult {
            content: None,
            tool_calls: vec![ApiToolCall {
                id: id.to_owned(),
                name: name.to_owned(),
                arguments: args.as_object().cloned().unwrap_or_default(),
            }],
        }
    }

    #[tokio::test]
    async fn returns_text_response_directly() {
        let model = MockModel::new(vec![text_response("Hello!")]);
        let tools = MockTools::with_outputs(HashMap::new());

        let result = run_agent_loop(
            &model,
            &[ConversationMessage::new("user", "Say hello.")],
            &tools,
            &[],
            None,
            AgentLoopOptions::default(),
        )
        .await
        .expect("loop should succeed");

        assert_eq!(result.answer, "Hello!");
        assert_eq!(result.iterations, 1);
        assert!(result.tool_results.is_empty());
    }

    #[tokio::test]
    async fn executes_tool_then_returns_answer() {
        let model = MockModel::new(vec![
            tool_call_response("call_1", "list_dir_tool", json!({"path": "."})),
            text_response("Found src and Cargo.toml."),
        ]);
        let tools = MockTools::with_outputs(HashMap::from([(
            "list_dir_tool".to_owned(),
            Ok("src\nCargo.toml".to_owned()),
        )]));
        let mut thoughts = RecordingThoughts::default();

        let result = run_agent_loop(
            &model,
            &[ConversationMessage::new("user", "List the repo.")],
            &tools,
            &[],
            Some(&mut thoughts),
            AgentLoopOptions::default(),
        )
        .await
        .expect("loop should succeed");

        assert_eq!(result.answer, "Found src and Cargo.toml.");
        assert_eq!(result.iterations, 2);
        assert_eq!(result.tool_results.len(), 1);
        assert_eq!(result.tool_results[0].id, "call_1");
        assert_eq!(result.tool_results[0].name, "list_dir_tool");
        assert_eq!(result.tool_results[0].result, "src\nCargo.toml");

        // Verify the second model request had the tool result message.
        let requests = model.requests.lock().await;
        assert_eq!(requests.len(), 2);
        let second = &requests[1];
        // Should contain a "tool" role message with the result.
        assert!(second.iter().any(|m| m.role == "tool"));
    }

    #[tokio::test]
    async fn records_unknown_tool_errors_without_failing_loop() {
        let model = MockModel::new(vec![
            tool_call_response("call_x", "missing_tool", json!({"path": "agent.py"})),
            text_response("Could not run it."),
        ]);
        let tools = MockTools::with_outputs(HashMap::new());

        let result = run_agent_loop(
            &model,
            &[ConversationMessage::new("user", "Use a missing tool.")],
            &tools,
            &[],
            None,
            AgentLoopOptions::default(),
        )
        .await
        .expect("loop should succeed");

        assert_eq!(result.answer, "Could not run it.");
        assert_eq!(result.tool_results.len(), 1);
        assert!(result.tool_results[0].error);
        assert_eq!(
            result.tool_results[0].result,
            "Unknown tool: missing_tool. Available: "
        );
    }

    #[tokio::test]
    async fn extracts_thoughts_from_content() {
        let model = MockModel::new(vec![text_response(
            "<thinking>I'll check the file.</thinking>The answer is 42.",
        )]);
        let tools = MockTools::with_outputs(HashMap::new());
        let mut thoughts = RecordingThoughts::default();

        let result = run_agent_loop(
            &model,
            &[ConversationMessage::new("user", "What's the answer?")],
            &tools,
            &[],
            Some(&mut thoughts),
            AgentLoopOptions::default(),
        )
        .await
        .expect("loop should succeed");

        assert_eq!(result.answer, "The answer is 42.");
        assert_eq!(thoughts.thoughts, vec!["I'll check the file."]);
    }

    #[tokio::test]
    async fn tool_call_ids_are_correlated_in_messages() {
        let model = MockModel::new(vec![
            tool_call_response("abc123", "list_dir_tool", json!({"path": "."})),
            text_response("Done."),
        ]);
        let tools = MockTools::with_outputs(HashMap::from([(
            "list_dir_tool".to_owned(),
            Ok("src".to_owned()),
        )]));

        run_agent_loop(
            &model,
            &[ConversationMessage::new("user", "List.")],
            &tools,
            &[],
            None,
            AgentLoopOptions::default(),
        )
        .await
        .expect("loop should succeed");

        let requests = model.requests.lock().await;
        let second = &requests[1];
        // The tool result message should have tool_call_id == "abc123".
        let tool_msg = second.iter().find(|m| m.role == "tool").expect("tool msg");
        assert_eq!(tool_msg.tool_call_id.as_deref(), Some("abc123"));
    }

    #[test]
    fn system_prompt_guides_counting_queries_toward_precise_tools() {
        assert!(SYSTEM_PROMPT.contains("identify the object type"));
        assert!(SYSTEM_PROMPT.contains("Do not substitute one object type for another"));
        assert!(SYSTEM_PROMPT.contains("If the requested object type is absent"));
        assert!(SYSTEM_PROMPT.contains("For counting, totals"));
        assert!(SYSTEM_PROMPT.contains("prefer a precise run_command_tool command"));
        assert!(SYSTEM_PROMPT.contains("interpret the concept semantically before searching"));
        assert!(SYSTEM_PROMPT.contains("Do not start with a literal phrase search"));
        assert!(SYSTEM_PROMPT.contains("pivot immediately to a structure-based search"));
        assert!(SYSTEM_PROMPT.contains("For tool definitions, inspect the full tool registry"));
        assert!(SYSTEM_PROMPT.contains("For routes, endpoints, or methods"));
        assert!(SYSTEM_PROMPT.contains("Do not assume \"routes\" means tools"));
        assert!(SYSTEM_PROMPT.contains("protocol server rather than an HTTP app"));
        assert!(SYSTEM_PROMPT.contains("depends on a complete inventory"));
        assert!(SYSTEM_PROMPT.contains("review the evidence already gathered"));
        assert!(SYSTEM_PROMPT.contains("Keep a short internal summary"));
        assert!(SYSTEM_PROMPT.contains("Do not reread the same file"));
        assert!(SYSTEM_PROMPT.contains("If one authoritative file"));
        assert!(SYSTEM_PROMPT.contains("Do not repeat the same search_code_tool query"));
        assert!(SYSTEM_PROMPT.contains("Treat tool output as ground truth"));
        assert!(SYSTEM_PROMPT.contains("Do not count `#[cfg(test)]`"));
        assert!(SYSTEM_PROMPT.contains("`#[tokio::test]`"));
    }
}
